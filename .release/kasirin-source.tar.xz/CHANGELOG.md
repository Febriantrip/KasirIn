# Changelog

## 0.11.0 - Internal SPA navigation

- Replaced browser-history routing with React Router `MemoryRouter`.
- POS and Back Office navigation no longer changes the browser address bar.
- Added per-tab internal route persistence so refresh restores the current workspace screen.
- Replaced hash-based skip links with focus-based skip controls to keep the URL completely stable.
- Added `check:spa-navigation` regression guard and documented the routing trade-offs in `SPA_NAVIGATION.md`.

## 0.9.0 — Extreme POS Performance Pass

- Split the styling graph so POS no longer parses Back Office feature/layout CSS on the initial register route; POS feature styles now load with their routes.
- Reduced the measured compiled CSS on the initial POS Sell path from 175,391 bytes to 64,073 bytes (~63.5%) without removing Aurora visuals.
- Rebuilt POS ambient Aurora blur layers with precomposed radial falloff and transform-only animation, and reduced repeated live backdrop sampling on dense card/list surfaces while retaining full glass treatment on important overlays.
- Isolated React hot paths with stable cart callbacks, identity-preserving row updates, memoized catalog/cards/list rows/details, one-pass cart totals, and deferred search work.
- Lazy-loaded checkout/customer/discount/sale-detail sheets plus secondary POS overlays and register lock; added intent-based route prefetch for fast navigation without eager-loading every POS feature.
- Added a POS route-loading skeleton that keeps the register shell visible during lazy route transitions.
- Made normal `npm run dev` suitable for interaction-performance testing without development-only StrictMode double invocation; added `npm run dev:strict` for explicit StrictMode audits.
- Added `npm run check:pos-performance` and `POS_PERFORMANCE.md` to preserve the optimization architecture.
- Preserved the complete POS UI/UX and feature set. No analytical/management capability was added to POS. Back Office feature/UX components were left unchanged; only stylesheet-loading infrastructure was separated.

## 0.8.0 — Richer Back Office Features & Workbench UX

- Added five Back Office-only management domains: Approval Center, Demand & Replenishment Planning, Data Operations, Integrations & Channels, and Audit & Activity.
- Added global Quick Create with `Alt+N`, a real notifications/exception drawer, navigation badges, and expanded command-palette workflows.
- Upgraded every standard Back Office module with saved views, refresh/freshness feedback, advanced-filter drawer, selectable records, bulk actions, column visibility, compact/comfortable table density, and activity-aware record inspection.
- Replaced toast-only primary module actions with a shared workflow-starter drawer that demonstrates validation, scoping, draft, and continuation patterns while remaining frontend-only.
- Enriched the dashboard with a management decision workbench linking approvals, planning, and data-quality attention queues.
- Preserved POS boundaries: no Back Office feature or UX source was added under POS, and POS source hashes remain unchanged from v0.7.
- Revalidated source structure, TypeScript, and the complete Sass tree. Vite bundling remains blocked only by the inherited Windows Rollup optional-binary mismatch in this Linux sandbox.

## 0.7.0 — Richer POS Operations & UX

- Added five POS-only operational modules: Price Check, Gift Cards & Store Credit, Pickup & Delivery Handoff, Offline & Sync Center, and Staff Switch & Supervisor Approval.
- Added F1 Quick Actions command dock shared across every POS route without expanding the primary cashier navigation.
- Expanded Sell with park-sale flow, In-store/Pickup/Delivery context, sale reference and note, item-level quantity/discount/note controls, and protected price override.
- Expanded Cash checkout with received-amount input, tender presets, shortage protection, and change calculation; expanded Split tender with allocation preview.
- Added register online status entry point and Price Check to the persistent POS quick bar.
- Removed analytical POS surfaces that did not belong at the register: Orders summary metrics, shift sales/tender-mix analysis, payment-method sales totals, and customer spend/visit stats. Operational lookup, drawer accountability, and transaction recovery remain.
- Preserved the hard workspace boundary: no dashboards, analytical reports, trends, margin analysis, purchasing, reconciliation analytics, pricing administration, or user administration were added to POS.
- Kept all new source files within modularity and file-size budgets and revalidated TypeScript, source structure, and Sass.

## 0.6.2 — POS Product Card Readability Fix

- Fixed POS Sell product-card text collisions introduced by the larger global typography scale.
- Changed product cards to a vertical flex layout so the stock label reserves its own space instead of being absolutely positioned over price text.
- Added safe two-line product-name clamping and single-line category/SKU truncation.
- Preserved the larger v0.6.1 font scale, Aurora visuals, cart layout, and all POS/Back Office feature behavior.

## 0.6.1 — Global Typography Readability Patch

- Increased the shared UI type scale across POS, Back Office, and the workspace gate without changing feature behavior.
- Raised microcopy from 6–8px into a more readable 8–10px band.
- Raised normal controls and supporting labels by roughly 1px while preserving large heading and metric hierarchy.
- Kept spacing, component sizing, route behavior, and POS/Back Office feature boundaries unchanged.
- Revalidated source structure, TypeScript, and the complete Sass tree after the typography adjustment.

## 0.6.0 — Back Office UX System

- Added Back Office-only UX provider, Aurora toast feedback, command palette, and shortcut guide.
- Added persisted collapsible sidebar and route-aware workspace context.
- Added keyboard shortcuts: Ctrl/Cmd+K, `/`, `[`, Shift+?, and Esc dismissal patterns.
- Added Back Office skip navigation, route announcements, consistent focus-visible styling, and reduced-motion handling.
- Standard module pages now support real text filtering, interactive tabs, quick-filter state, sortable tables, record counts, contextual empty states, and quick-inspect row drawers.
- Dashboard actions now navigate or provide explicit feedback instead of remaining inert.
- Preserved the POS/Back Office boundary: no POS source files were changed for this UX release.

## 0.5.0 - POS UX system

- Added a POS-only shared UX provider for Aurora toasts, confirmations, and shortcut help.
- Added F2 / Ctrl+K primary-search focus, Alt+1..5 primary POS navigation, F9 register lock, and Shift+? shortcut guide.
- Added accessible dialog focus trapping, Escape dismissal, route announcements, skip link, focus-visible states, reduced-motion support, and coarse-pointer touch sizing.
- Added reusable POS empty states and corrected stale detail panels after filtered searches.
- Added confirmation and feedback patterns to cart clearing, returns, shift closing, cash movement, held carts, promotions, discounts, loyalty, payment preview, receipt/device actions, and settings.
- Added keyboard-first register lock behavior.
- Kept all UX additions inside POS boundaries; Back Office behavior and features are unchanged.


## 0.4.0 - Full Back Office Frontend Template

- Replaced the generic Back Office catch-all workspace page with 14 explicit, lazy-loaded management feature routes.
- Added full frontend templates for Sales Management, Catalog, Pricing, Promotions, Inventory, Purchasing, Suppliers, Customers, Loyalty, Stores & Registers, Reconciliation, Users & Access, Reports & Analytics, and Retail Settings.
- Added reusable Back Office-only feature header, metric strip, tabs, filter bar, data table, status badge, insight panel, and module composition primitives.
- Added feature-owned configuration datasets so each Back Office area remains independently maintainable without giant shared registries.
- Removed the obsolete Back Office `workspace/` catch-all module and related styles.
- Expanded route constants to explicit Back Office route names.
- Preserved POS scope with no analytical, purchasing, reconciliation, access-control, or administrative feature leakage.
- Added `BACKOFFICE_FEATURES.md` with workspace boundary rules and future integration seams.
- Preserved source-size budgets and modularity validation.

## 0.3.0 - Full POS Frontend Template

- Expanded POS from 3 routes to a complete cashier-facing retail workspace.
- Added held carts, returns, customers, loyalty, discounts, stock lookup, cash management, payments, receipts, tools, and register settings.
- Upgraded Sell with customer attach, basket discounts, checkout tender selection, split-payment pattern, and mock payment completion.
- Expanded Orders with searchable history, status filters, order detail, reprint/send/return actions, and transaction metrics.
- Expanded Shift with tender mix, audit activity, expected drawer, and closing-count workflow.
- Added register lock screen with local mock PIN state.
- Added workspace-local reusable POS page headers, metrics, status badges, search, and section-card primitives.
- Added responsive feature styles while preserving the source-size budgets.
- Added `POS_FEATURES.md` to document the frontend-only surface and future integration boundaries.

## 0.2.0 - Modularity Standardization

- Replaced generic `modules/` structure with feature-first `features/` slices.
- Split POS sell into page, components, hook, mock data, types, and calculation utility.
- Standardized naming, foldering, imports, style layers, lazy routing, and automated source-size checks.

## 0.10.0 - Back Office extreme performance pass

- Split Back Office shell, dashboard, module, and overlay styles so screens load only the CSS they use.
- Added route-intent prefetching and an in-shell route loading skeleton.
- Lazy-loaded command palette, notification center, quick create, shortcut guide, row inspector, workflow starter, and advanced filters.
- Deferred/cached module search work and isolated stable module surfaces with memoization.
- Optimized table selection/sorting and memoized repeated rows.
- Rebuilt the Back Office ambient Aurora glow without animated blur filters while preserving its visual character.
- Added paint/layout containment and content visibility for dense repeated management surfaces.
- Added `check:backoffice-performance` and `BACKOFFICE_PERFORMANCE.md`.
- POS source and UX remain unchanged by this performance pass.
