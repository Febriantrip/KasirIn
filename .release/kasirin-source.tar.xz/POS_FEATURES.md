# Aurora POS Frontend Feature Inventory

Version 0.7 expands Aurora POS into a richer cashier operations template while remaining frontend-only and deliberately non-analytical.

## Primary selling flow

- Product search, SKU search, barcode-ready input, category filtering, stock visibility, and quick add.
- Cart quantity changes, line removal, item-level notes, item discounts, and protected price-override pattern.
- Basket discount / promo selection, subtotal, item discount, basket discount, tax, and total calculation.
- Customer attach with loyalty context.
- Sale context for **In-store**, **Pickup**, and **Delivery**, including a cashier-visible reference and order note.
- Park-sale action from checkout with Held Cart recovery pattern.
- Cash, Card, QRIS, and Split tender selection.
- Cash-received input, quick cash presets, shortage protection, and change calculation.
- Split-tender allocation preview, mock approval, receipt handoff, and fresh-sale reset.

## Cashier assist & customer service

- **Price Check**: scan/search product, confirm current selling price, variant, barcode, offer label, and local availability.
- **Gift Cards & Store Credit**: lookup, balance check, issue/load/redeem interaction patterns.
- **Pickup & Delivery Handoff**: active order queue, preparing/ready/handoff states, customer contact, and courier/pickup instructions.
- **Stock Lookup**: cashier-facing availability across relevant locations for customer service.
- **Customers & Loyalty**: lookup, attach, points, rewards, and customer-service context.
- **Discounts & Promos**: cashier application flow and supervisor-approval pattern.

## Transaction operations

- Order search and status filtering.
- Transaction detail, payment method, item breakdown, tax, discount, and totals.
- Reprint, resend, and return entry points.
- Held carts with recall, expiry context, notes, and delete pattern.
- Return workflow with receipt lookup, eligible quantities, reason, restock treatment, and refund method.
- Receipt center with preview, print, email, and WhatsApp handoff patterns.

## Register operations

- Shift open/close workflow, expected drawer, tender accountability, and cashier audit events required to close a register.
- Cash drawer opening float, paid-in, paid-out, safe drop, and register cash activity.
- Payment-tender readiness and register-local payment attempt troubleshooting.
- **Staff Switch & Supervisor Approval**: switch the active cashier or authorize a protected POS action without exposing user administration.
- **Offline & Sync Center**: online/offline state, local transaction queue, retry-one, and retry-all interaction patterns.
- Cashier lock screen with keyboard and onscreen PIN flow.
- Register-local peripherals and POS preferences.

## Shared POS UX

- F1 **Quick Actions** command dock for operational tools without bloating primary navigation.
- F2 / Ctrl+K primary-search focus, Alt+1..5 navigation, F9 lock, and Shift+? shortcut guide.
- Aurora toasts, confirmations, focus trapping, keyboard dismissal, route announcements, empty states, and accessible focus rings.
- Persistent operational quick bar for Held Carts, Returns, Stock, Price Check, Customer, and Lock.
- Responsive touch targets and reduced-motion support.

## Strict POS / Back Office boundary

POS may **execute and recover retail operations**, but it must not analyze or administer the business.

The following remain Back Office only:

- Executive / store / product performance dashboards.
- Sales trends, cohort analysis, basket analysis, conversion, margin, or profitability views.
- Price-book creation, bulk pricing, margin controls, and pricing analytics.
- Promotion campaign administration and performance analytics.
- Inventory planning, replenishment analysis, stocktake administration, and movement analytics.
- Purchasing and supplier administration.
- Settlement / reconciliation analytics and finance controls.
- Organization-wide user, role, permission, store, and register administration.
- Scheduled reports, exports, dashboards, and analytical report builders.

Operational values required to finish a sale or close a shift are allowed in POS; analytical interpretation of those values belongs in Back Office.

## Frontend-only boundary

These features are templates and must be connected later to real services:

- Authentication, cashier identity, permissions, and supervisor authorization.
- Product, price, gift-card, customer, inventory, order, loyalty, and fulfillment APIs.
- Payment terminals, QR providers, gift-card processors, settlement providers, and refunds.
- Receipt printers, cash drawers, scanners, customer displays, and other register peripherals.
- Persistent held carts, shift state, sale notes, line overrides, and fulfillment updates.
- Offline storage, sync retries, conflict resolution, and audit persistence.

Feature-local mocks and local React state keep those future integrations replaceable without redesigning the UI.
