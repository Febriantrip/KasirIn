# Aurora Retail UI Template

Frontend-only React + TypeScript template for two intentionally separate retail workspaces.

- **Aurora POS**: cashier execution for selling, checkout, held carts, returns, customer service, price check, gift cards, pickup/delivery handoff, loyalty, discounts, stock lookup, shifts, cash movement, payments, receipts, staff handoff, offline/sync recovery, register tools, lock state, and device-local settings.
- **Aurora Back Office**: retail management, configuration, approvals, planning, data operations, integrations, control, supply operations, customer administration, reconciliation, auditability, and analytics.

Both workspaces share Aurora's glass, motion, spacing, and component DNA while keeping separate shells, navigation, feature boundaries, and color identities.

The default typography scale is tuned for compact retail density while keeping supporting text readable; microcopy is no longer rendered at the previous 6–8px baseline.

## Stack

- React 19
- TypeScript
- Vite
- React Router
- Sass
- Lucide icons

This repository intentionally contains **no backend, API contract, database schema, real authentication, payment-provider integration, printer driver, or persistent state**. UI interactions use local React state and seeded frontend data only.

## Workspace boundary

POS is optimized for fast cashier execution. Back Office is optimized for management and control. Analytical dashboards, price-book administration, purchasing, reconciliation, access control, reporting, and organization-wide settings belong only to Back Office.

See [`POS_FEATURES.md`](./POS_FEATURES.md) and [`BACKOFFICE_FEATURES.md`](./BACKOFFICE_FEATURES.md) for full feature inventories.

## Back Office routes

`/backoffice` plus dedicated routes for sales, catalog, pricing, promotions, inventory, demand planning, purchasing, suppliers, customers, loyalty, approval center, stores, reconciliation, users, audit, reports, data operations, integrations, and settings.

## Commands

```bash
npm install
npm run dev
npm run dev:strict   # optional StrictMode audit
npm run validate
npm run build
```

## Architecture

See [`ARCHITECTURE.md`](./ARCHITECTURE.md) for enforced folder, naming, import, feature-boundary, and source-size conventions.

The core rule remains: pages compose, components render, hooks orchestrate state, utils calculate, configs/mocks seed demo data, and reusable contracts live in shared layers.

## POS performance architecture

The POS uses workspace/route CSS splitting, compositor-friendly Aurora effects, render isolation for cart/list hot paths, deferred search, lazy secondary overlays, and intent-based route prefetching. The visual and interaction quality remains unchanged while the register path does substantially less work.

See [`POS_PERFORMANCE.md`](./POS_PERFORMANCE.md) for the performance contract, measured CSS reduction, and regression guard.

## POS UX system

The POS workspace includes a shared Aurora UX layer for F1 Quick Actions, keyboard shortcuts, feedback, confirmation, dialog focus, empty states, route announcements, touch/focus states, protected-action patterns, and cashier-safe recovery flows. See `POS_UX.md`.


## UX documentation

- `POS_UX.md` documents the cashier-focused POS interaction system.
- `BACKOFFICE_UX.md` documents the management-focused Back Office interaction system.

## Back Office workbench

The Back Office now includes a richer shared management workbench: saved views, advanced filters, selectable/sortable tables, bulk actions, column visibility, row density, activity-aware quick inspect, global quick create, notification/exception center, and workflow-starter drawers. These patterns remain Back Office-only.

## Back Office performance architecture

The Back Office now mirrors the POS performance discipline without copying its UX model: shell/dashboard/module/overlay CSS is split by use, management overlays are lazy, module search is deferred and cached, repeated tables/cards are render-isolated, and Back Office route chunks preload on navigation intent. The cool Aurora visual language remains intact.

Run `npm run check:backoffice-performance` to protect these contracts. See [`BACKOFFICE_PERFORMANCE.md`](./BACKOFFICE_PERFORMANCE.md) for the implementation notes and measured stylesheet reduction.
## URL-stable SPA navigation

The template uses an internal memory router. Moving between POS, Back Office, and their feature screens does not change the browser address bar. The active internal screen is restored on refresh within the same browser tab. See `SPA_NAVIGATION.md` for details and trade-offs.

