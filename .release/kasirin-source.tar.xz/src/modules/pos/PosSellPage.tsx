import { useMemo, useState } from 'react';
import { Barcode, ChevronRight, Minus, Plus, Search, Sparkles, Trash2, UserPlus, WalletCards, X } from 'lucide-react';

const products = [
  { id: 1, name: 'KasirIn Daily Tee', sku: 'TS-001', category: 'Apparel', price: 149000, stock: 18, tone: 'coral' },
  { id: 2, name: 'Cloud Tote Bag', sku: 'BG-014', category: 'Accessories', price: 89000, stock: 9, tone: 'mint' },
  { id: 3, name: 'Nightfall Cap', sku: 'CP-020', category: 'Accessories', price: 119000, stock: 13, tone: 'violet' },
  { id: 4, name: 'Orbit Bottle 600ml', sku: 'BT-104', category: 'Lifestyle', price: 99000, stock: 26, tone: 'sky' },
  { id: 5, name: 'Softline Socks', sku: 'SK-008', category: 'Apparel', price: 49000, stock: 33, tone: 'pink' },
  { id: 6, name: 'Lumen Notebook', sku: 'NB-011', category: 'Stationery', price: 59000, stock: 21, tone: 'amber' },
];

type CartLine = (typeof products)[number] & { qty: number };
const rupiah = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', maximumFractionDigits: 0 });

export function PosSellPage() {
  const [query, setQuery] = useState('');
  const [cart, setCart] = useState<CartLine[]>([
    { ...products[0], qty: 1 },
    { ...products[3], qty: 2 },
  ]);
  const filtered = products.filter((p) => `${p.name} ${p.sku} ${p.category}`.toLowerCase().includes(query.toLowerCase()));
  const subtotal = useMemo(() => cart.reduce((sum, line) => sum + line.price * line.qty, 0), [cart]);
  const tax = subtotal * 0.11;
  const total = subtotal + tax;

  const add = (product: (typeof products)[number]) => setCart((current) => {
    const existing = current.find((line) => line.id === product.id);
    return existing ? current.map((line) => line.id === product.id ? { ...line, qty: line.qty + 1 } : line) : [...current, { ...product, qty: 1 }];
  });
  const updateQty = (id: number, delta: number) => setCart((current) => current.map((line) => line.id === id ? { ...line, qty: Math.max(1, line.qty + delta) } : line));

  return (
    <section className="pos-sell fade-in">
      <div className="pos-catalog">
        <div className="pos-page-head">
          <div><p className="eyebrow"><Sparkles size={12}/> New sale</p><h1>What are we selling?</h1></div>
          <span className="pos-order-id">Order <b>#A-240918</b></span>
        </div>
        <label className="pos-search glass-panel"><Search size={18}/><input autoFocus value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search product, SKU, or scan barcode..."/><kbd>F2</kbd><Barcode size={18}/></label>
        <div className="category-strip">
          {['All', 'Apparel', 'Accessories', 'Lifestyle', 'Stationery'].map((c, index) => <button className={index === 0 ? 'is-active' : ''} key={c}>{c}</button>)}
        </div>
        <div className="product-grid">
          {filtered.map((product) => (
            <button className="product-card glass-panel" key={product.id} onClick={() => add(product)}>
              <span className={`product-art product-art--${product.tone}`}><i/><em>{product.name.slice(0, 1)}</em></span>
              <span className="product-card__body"><small>{product.category} · {product.sku}</small><strong>{product.name}</strong><b>{rupiah.format(product.price)}</b></span>
              <span className="product-stock">{product.stock} in stock</span>
              <span className="product-add"><Plus size={16}/></span>
            </button>
          ))}
        </div>
      </div>

      <aside className="pos-cart glass-panel">
        <div className="pos-cart__head"><div><small>Current cart</small><h2>{cart.length} items</h2></div><button className="icon-button"><X size={17}/></button></div>
        <button className="customer-attach"><span><UserPlus size={17}/></span><div><strong>Attach customer</strong><small>Optional · loyalty & history</small></div><ChevronRight size={16}/></button>
        <div className="cart-lines">
          {cart.map((line) => (
            <article className="cart-line" key={line.id}>
              <span className={`cart-line__art product-art--${line.tone}`}>{line.name.slice(0,1)}</span>
              <div className="cart-line__main"><strong>{line.name}</strong><small>{rupiah.format(line.price)}</small><div className="qty-stepper"><button onClick={() => updateQty(line.id, -1)}><Minus size={13}/></button><b>{line.qty}</b><button onClick={() => updateQty(line.id, 1)}><Plus size={13}/></button></div></div>
              <div className="cart-line__side"><b>{rupiah.format(line.price * line.qty)}</b><button onClick={() => setCart((current) => current.filter((item) => item.id !== line.id))}><Trash2 size={14}/></button></div>
            </article>
          ))}
        </div>
        <button className="discount-row"><span>Discount / promo</span><b>Add <ChevronRight size={14}/></b></button>
        <div className="cart-summary"><span><small>Subtotal</small><b>{rupiah.format(subtotal)}</b></span><span><small>Tax 11%</small><b>{rupiah.format(tax)}</b></span><span className="cart-total"><strong>Total</strong><strong>{rupiah.format(total)}</strong></span></div>
        <button className="pay-button"><span><WalletCards size={19}/> Pay now</span><b>{rupiah.format(total)}</b></button>
        <div className="payment-hints"><span>Cash</span><span>Card</span><span>QRIS</span><span>Split</span></div>
      </aside>
    </section>
  );
}
