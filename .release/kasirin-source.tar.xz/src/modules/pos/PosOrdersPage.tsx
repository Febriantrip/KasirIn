import { Clock3, ReceiptText, RotateCcw, Search, ShoppingBag } from 'lucide-react';
const orders = [
  ['#A-240917', '10:21', 'Walk-in customer', 'Rp 426.240', 'Paid'],
  ['#A-240916', '10:08', 'Alya Pratama', 'Rp 782.550', 'Paid'],
  ['#A-240915', '09:46', 'Walk-in customer', 'Rp 198.690', 'Held'],
  ['#A-240914', '09:12', 'Raka D.', 'Rp 1.094.350', 'Paid'],
];
export function PosOrdersPage(){return <section className="pos-simple-page fade-in"><div className="pos-page-head"><div><p className="eyebrow"><ReceiptText size={12}/> Transaction desk</p><h1>Orders & held carts</h1></div></div><label className="pos-search glass-panel"><Search size={18}/><input placeholder="Search receipt, customer, or amount..."/></label><div className="pos-order-list glass-panel">{orders.map(([id,time,name,total,status])=><article key={id}><span className="order-icon"><ShoppingBag size={16}/></span><div><strong>{id}</strong><small>{name}</small></div><span><Clock3 size={13}/>{time}</span><b>{total}</b><em className={status==='Held'?'is-held':''}>{status}</em><button>{status==='Held'?'Recall':'View'}</button></article>)}</div><div className="pos-support-actions"><button><RotateCcw size={16}/> Start a return</button></div></section>}
