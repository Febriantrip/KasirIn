import React from 'react';
import ReactDOM from 'react-dom/client';
import { MemoryRouter } from 'react-router-dom';
import App from './app/App';
import { getInitialInternalRoute } from './app/router/internalRouteState';
import './styles/index.scss';

const app = (
  <MemoryRouter initialEntries={[getInitialInternalRoute()]}>
    <App />
  </MemoryRouter>
);

const root = ReactDOM.createRoot(document.getElementById('root')!);
const strictModeEnabled = import.meta.env.VITE_REACT_STRICT_MODE === 'true';
root.render(strictModeEnabled ? <React.StrictMode>{app}</React.StrictMode> : app);
